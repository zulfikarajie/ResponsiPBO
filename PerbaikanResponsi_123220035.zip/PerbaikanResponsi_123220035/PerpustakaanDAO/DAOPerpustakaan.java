package PerpustakaanDAO;

import ModelPackage.ModelData;
import java.util.List;

public interface DAOPerpustakaan {
    List<ModelData> getALL();
    void insert(ModelData data);
    void update(ModelData data);
    void delete(int id);
}
